

import static java.lang.Math.PI;

public class Circulo extends LaFigura{

    private float radio;
    
    public Circulo(){
      //  this.radio = 50;
    }
    
    public Circulo(float valorRadio) {
        this.radio = valorRadio;
    }
    
    private void calcularArea(){
        this.setArea((float) ((this.radio*this.radio)*PI));
    }
    
    public float ImprimirArea(){
      this.calcularArea();
       
      return  this.getArea();
    }
    private void Perimetro(){
      this.setPerimetro((float) PI*(2*this.radio)) ;   
    }
    public float ImprimirPerimetro(){
     this.Perimetro();
       
    return  this.getPerimetro();
    }
    public  void setRadio(float a){
      this.radio=a;  
    }
    }
