

import static java.lang.Math.PI;
import javax.swing.JTextPane;


public class Triangulo extends LaFigura{

private float base;
private float altura; 
public float cc; 
    public Triangulo() {
   //Calcular_area();
   // Perimetro();
    }   

 private void Calcular_area(){
   this.setArea((this.base*this.altura)/2); 
    }
   private void Perimetro(){
  //  this.setPerimetro((2*(this.base+this.altura+this.altura)));
  this.setPerimetro((float) Math.hypot(base, altura)+base+altura); 
   }
   public   float Imprimir_area(){
    Calcular_area();    
   
    return  this.getArea();
   }
   public  float Imprimir_perimetro(){
    Perimetro();
       
   return   this.getPerimetro();
   }
   public void  setBase(float B){
    this.base=B;   
 
    }
   public void  setAltura(float B){
    this.altura=B;   
 
   }
   
}
