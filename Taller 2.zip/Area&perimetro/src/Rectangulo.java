



public class Rectangulo extends LaFigura{
 private float base=7;
 private float altura=5; 

   public Rectangulo() {
   Calcular_area();
   Perimetro();
   }
   private void Calcular_area(){
   this.setArea(this.base*this.altura); 
    }
   private void Perimetro(){
    this.setPerimetro((2*(this.base+this.altura))) ;//Falta arreglar este 
    }
   public float   Imprimir_area(){
     Calcular_area();
     return  this.getArea();
     
   }
   public  float Imprimir_perimetro(){
      Perimetro();
      return this.getPerimetro();
    
    }
   public void setBase(float a){//De esta manera obtengo los datos desde la clase AreaGui
      this.base=a;
   }
   public void setAltura(float a){//De esta manera obtengo los datos desde la clase AreaGui
      this.altura=a;  
   }
}
