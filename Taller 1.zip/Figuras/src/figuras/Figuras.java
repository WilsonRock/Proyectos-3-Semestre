package figuras;

public class Figuras {
    
    public static void main(String[] args) {
        Menu obj = new Menu();
    }
    
}
