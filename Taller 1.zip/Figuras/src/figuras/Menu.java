package figuras;

import java.util.Scanner;

public class Menu {

    public Menu() {
        this.inicio();
    }   
    
    private void imprimirMenuPrincipal(){
        System.out.println("=============================");
        System.out.println("Menu Principal \n");
        System.out.println("1-Circulo");
        System.out.println("2-Rectangulo");
        System.out.println("4-Salir");
    }
    
    private void imprimirMenuCirculo(){
        System.out.println("=============================");
        System.out.println("Menu Circulo \n");
        System.out.println("1-Imprimir Area");
        System.out.println("2-Imprimir Perimetro");
        System.out.println("4-Salir");
    }
    
    private void inicioCirculo(){
    int temp = 0;
        
        while(temp == 0){            
            this.imprimirMenuCirculo();//imprime el menu
            Scanner valor = new Scanner(System.in);
            int entradaTeclado = valor.nextInt();
            
            switch(entradaTeclado){
                case 1:                    
                    Circulo objeto = new Circulo(20);
                    objeto.imprimirArea();
                    break;
                case 2:
                    System.out.println("Perimetro");
                    break;
                case 4:
                    temp = 1;
                    break;
            }
            
        }
    }
    
    private void inicio(){
        int temp = 0;
        
        while(temp == 0){            
            this.imprimirMenuPrincipal();
            Scanner valor = new Scanner(System.in);
            int entradaTeclado = valor.nextInt();
            
            switch(entradaTeclado){
                case 1:
                    
                    this.inicioCirculo();
                    break;
                case 2:
                    System.out.println("rectangulo");
                    break;
                case 4:
                    temp = 1;
                    break;
            }
            
        }                
    }
}
