package figuras;

import static java.lang.Math.PI;

public class Circulo extends LaFigura{

    private float radio;
    
    public Circulo(){
        this.radio = 50;
    }
    
    public Circulo(float valorRadio) {
        this.radio = valorRadio;
    }
    
    private void calcularArea(){
        this.setArea((float) ((this.radio*this.radio)*PI));
    }
    
    public void imprimirArea(){
        this.calcularArea();
        System.out.println("El valor del area del circulo es :");
        System.out.println(this.getArea());
    }
    
}
