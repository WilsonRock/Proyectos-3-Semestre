
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author REY PEREZ
 */
public class bmw_Mazda extends Exception {
 public  bmw_Mazda() {
        super();
    }

    public  bmw_Mazda(String message) {
        super(message);
        JOptionPane.showMessageDialog(null,message, "Advertencia", JOptionPane.WARNING_MESSAGE);
    }   
}
